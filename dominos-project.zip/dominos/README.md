# DOMINOS — startprojekt

Det här är ett första Next.js-gränssnitt för DOMINOS.

## Starta lokalt
1. Installera Node.js (LTS) från https://nodejs.org
2. Öppna terminalen i projektmappen.
3. Kör `npm install`
4. Kör `npm run dev`
5. Öppna http://localhost:3000

## Publicera på Vercel
1. Lägg projektet i ett GitHub-repository.
2. På https://vercel.com/new väljer du Import Git Repository.
3. Välj repositoryt och klicka Deploy.

## Viktigt
Detta är en frontend-prototyp. Meddelanden är tillfälliga och kontoinloggningen är ännu inte aktiv. Innan riktiga användare kan registrera sig måste autentisering, databas, behörigheter, moderering och säkerhetsregler byggas och testas. Lägg aldrig lösenord eller hemliga nycklar i koden eller i chatten.
